package com.Adimo.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DesenvolvimentoWebSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
