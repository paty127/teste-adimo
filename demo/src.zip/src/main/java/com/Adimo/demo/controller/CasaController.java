package com.Adimo.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CasaController {
	
	@Autowired
	private CasaRepository ir;
	
	Set<Casa> favoritos = new HashSet<Casa>();
	
	
	@GetMapping("/casa/detalhes/{id}")
	public String detalhes(@PathVariable("id") Integer id, Model model) {
		model.addAttribute("casa", ir.buscaCasaPorId(id));
		return ("detalhes");
	}
	
	@GetMapping("/casa/add")
	public ResponseEntity<Imovel> addFavorito(@RequestParam(required = false) Integer id) {

		if (id != null) {
			favoritos.add(ir.buscaCasaPorId(id));
		}
		return ResponseEntity.ok().body(null);
	}
	
	@GetMapping("/casa/favorito")
	public String favorito(Model model) {
		model.addAttribute("casa", favoritos);
		return ("favoritos");
	}
	
	@GetMapping("/casa/favoritos/delete")
	public String deletaFavoritos(@RequestParam("id") Integer id, Model model) {
		favoritos.remove(ir.buscaCasaPorId(id));
		return ("redirect:/casa/favorito");
	}
}


}
